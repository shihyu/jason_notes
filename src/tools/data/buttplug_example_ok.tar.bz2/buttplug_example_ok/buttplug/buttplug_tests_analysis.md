# Buttplug 測試分析報告

## 測試架構概述

Buttplug 是一個開源的成人玩具控制框架，採用 Rust 編寫。測試套件包含多層次的測試，涵蓋客戶端、伺服器、裝置協議等各個面向。

## 測試檔案結構

### 主要測試檔案

#### 1. 客戶端測試 (`test_client.rs`)
- **連接測試**：測試客戶端與伺服器的連接/斷線功能
- **握手測試**：驗證客戶端初始化和伺服器資訊交換
- **掃描測試**：測試裝置掃描的啟動、停止、重複調用
- **Ping 測試**：測試客戶端與伺服器間的心跳機制
- **錯誤處理**：測試連接失敗、重複斷線等錯誤場景

主要測試案例：
- `test_failing_connection()` - 測試連接失敗處理
- `test_disconnect_status()` - 測試斷線狀態
- `test_client_ping()` - 測試 ping 超時機制
- `test_start_scanning()` - 測試裝置掃描功能

#### 2. 伺服器測試 (`test_server.rs`)
- **握手協議**：測試不同版本的客戶端與伺服器握手
- **版本相容性**：測試新舊版本間的相容性
- **Ping 超時**：測試伺服器端的 ping 超時處理
- **裝置管理**：測試裝置索引生成、裝置添加/移除事件

主要測試案例：
- `test_server_handshake()` - 測試伺服器握手
- `test_client_version_older_than_server()` - 測試版本相容性
- `test_ping_timeout()` - 測試 ping 超時機制
- `test_device_index_generation()` - 測試裝置索引分配

#### 3. 裝置協議測試 (`test_device_protocols.rs`)
這是最龐大的測試模組，包含超過 130+ 個不同品牌裝置的協議測試：

**主要品牌包含**：
- **Lovense**: 單震動器、Max、Nora、Ridge、Edge、Osci3 等
- **Satisfyer**: 單震動、雙震動、三震動裝置
- **WeVibe**: 4Plus、Pivot、Vector、Moxie、Chorus
- **Vorze**: UFO、Cyclone 等旋轉裝置
- **Svakom**: Alex、Ella、Theodore 等多系列
- **MagicMotion**: Magic Cell、Eidolon、Krush 等
- **其他品牌**: Aneros、Hismith、Lelo、Kiiroo、Galaku 等

測試版本：
- `test_device_protocols_embedded_v3()` - 內嵌式測試 v3
- `test_device_protocols_json_v3()` - JSON 序列化測試 v3
- `test_device_protocols_embedded_v2()` - 內嵌式測試 v2
- `test_device_protocols_json_v2()` - JSON 序列化測試 v2

#### 4. 客戶端裝置測試 (`test_client_device.rs`)
- **裝置連接狀態**：測試裝置連接/斷線狀態追蹤
- **指令驗證**：測試無效指令的錯誤處理
- **訊息重複**：測試重複裝置添加/移除訊息的處理
- **範圍限制**：測試使用者自定義的裝置控制範圍

主要測試案例：
- `test_client_device_connected_status()` - 裝置連接狀態測試
- `test_client_device_invalid_command()` - 無效指令測試
- `test_client_range_limits()` - 範圍限制測試

#### 5. 序列化測試 (`test_serializers.rs`)
- **錯誤訊息中繼**：測試錯誤訊息的序列化和傳遞
- **損壞資料處理**：測試處理損壞的 JSON 資料

#### 6. WebSocket 連接器測試 (`test_websocket_connectors.rs`)
- **網路連接測試**：測試 WebSocket 客戶端和伺服器連接
- 目前被註解掉，僅在 Windows 平台上執行

### 測試工具類

#### 裝置測試案例 (YAML 格式)
裝置協議測試使用 YAML 檔案定義測試案例，包含：

**YAML 結構**：
```yaml
devices:
  - identifier:
      name: "裝置名稱"
    expected_name: "預期顯示名稱"

device_init: # 裝置初始化步驟
  - !Commands
      device_index: 0
      commands:
        - !Subscribe
        - !Write

device_commands: # 測試指令序列
  - !Messages
      device_index: 0
      messages:
        - !Vibrate
          - Index: 0
            Speed: 0.5
  - !Commands
      device_index: 0
      commands:
        - !Write
            endpoint: tx
            data: [0x86, 0x105, ...]
```

**測試流程**：
1. 初始化裝置（訂閱端點、發送初始化指令）
2. 執行測試指令（震動、旋轉、直線運動等）
3. 驗證硬體指令輸出
4. 測試停止指令

#### 測試輔助工具

**TestDeviceCommunicationManagerBuilder**: 
- 模擬硬體裝置的通信管理器
- 提供測試裝置的添加和管理功能

**ChannelClientTestHelper**:
- 提供通道測試的輔助功能
- 模擬客戶端-伺服器間的訊息傳遞

## 測試覆蓋範圍

### 功能測試
1. **連接管理** - 客戶端與伺服器的連接生命週期
2. **協議相容性** - 多版本訊息協議的相容性
3. **裝置控制** - 各種裝置的控制指令和回應
4. **錯誤處理** - 各種錯誤場景的處理機制
5. **效能測試** - Ping 超時、連接超時等

### 協議測試
- **130+ 裝置協議**：涵蓋市面上主流成人玩具品牌
- **多種功能類型**：震動、旋轉、直線運動、電池狀態等
- **版本相容性**：支援 v2、v3 等多個協議版本

### 整合測試
- **端到端測試**：從客戶端指令到硬體輸出的完整流程
- **併發測試**：多裝置同時操作的場景
- **網路測試**：WebSocket 連接的穩定性

## 測試特點

### 優點
1. **全面覆蓋**：涵蓋了框架的各個層面
2. **實際場景**：使用真實裝置協議進行測試
3. **版本相容**：確保向後相容性
4. **模組化設計**：測試結構清晰，易於維護
5. **自動化程度高**：使用 YAML 配置驅動測試

### 測試策略
1. **單元測試**：針對各個模組的獨立功能
2. **整合測試**：測試模組間的交互
3. **協議測試**：確保裝置協議的正確實作
4. **錯誤測試**：驗證錯誤處理機制
5. **效能測試**：確保系統響應性能

## 結論

Buttplug 的測試套件展現了高品質的軟體開發實踐，特別是在硬體設備控制這樣的複雜領域。測試覆蓋了從低層硬體通信到高層客戶端 API 的完整技術棧，確保了系統的穩定性和可靠性。

測試設計的模組化和 YAML 驅動的方式，使得新增裝置支援變得相對簡單，同時保持了測試的一致性和可維護性。