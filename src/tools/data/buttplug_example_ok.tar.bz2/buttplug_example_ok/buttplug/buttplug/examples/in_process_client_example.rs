use buttplug::{client::ButtplugClientEvent, util::in_process_client};
use futures_util::StreamExt;
use std::sync::Arc;
use tracing_subscriber;

#[tokio::main(flavor = "current_thread")]
async fn main() -> anyhow::Result<()> {
  // 啟用詳細日誌
  tracing_subscriber::fmt()
    .with_max_level(tracing::Level::DEBUG)
    .init();

  println!("Starting Buttplug in-process client example...");

  // Create an in-process client with automatic server setup
  // Second parameter false = don't load user device config
  // let client = in_process_client("Example Client", true).await;
  let client = in_process_client("Example Client", false).await;

  println!("Client created successfully!");
  println!("Client connected: {}", client.connected());

  // Wait a bit for adapters to initialize
  println!("Waiting for adapters to initialize...");
  tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;

  // Set up event listener
  let mut event_stream = client.event_stream();

  // Spawn task to handle events
  let event_client = Arc::new(client);

  tokio::spawn(async move {
    while let Some(event) = event_stream.next().await {
      match event {
        ButtplugClientEvent::DeviceAdded(device) => {
          println!("🎉 Device added: {}", device.name());
          println!("   Index: {}", device.index());
        }
        ButtplugClientEvent::DeviceRemoved(device) => {
          println!("❌ Device removed: {}", device.name());
        }
        ButtplugClientEvent::ScanningFinished => {
          println!("🔍 Scanning finished");
        }
        ButtplugClientEvent::ServerDisconnect => {
          println!("📡 Server disconnected");
          break;
        }
        _ => {
          println!("📝 Other event: {:?}", event);
        }
      }
    }
  });

  // Start device scanning
  println!("Starting device scan...");
  println!("🔍 正在掃描 BX288A 和 ERICA 設備...");
  println!("📝 注意：設備可能在日誌中出現但因協定問題不會加入設備列表");

  if let Err(e) = event_client.start_scanning().await {
    println!("Failed to start scanning: {}", e);
  }

  // Wait longer for device discovery and check devices periodically
  for i in 1..=10 {
    tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
    let devices = event_client.devices();
    println!(
      "Scan progress {}/10 - Found {} devices so far",
      i,
      devices.len()
    );
    for device in &devices {
      println!("  - {} (index: {})", device.name(), device.index());
    }

    // 特別檢查是否找到你的設備
    if devices
      .iter()
      .any(|d| d.name().contains("BX288A") || d.name().contains("ERICA"))
    {
      println!("✅ 找到你的設備了！");
      break;
    }
  }

  // Stop scanning
  println!("Stopping device scan...");
  if let Err(e) = event_client.stop_scanning().await {
    println!("Failed to stop scanning: {}", e);
  }

  // List connected devices
  let devices = event_client.devices();
  let device_count = devices.len();
  println!("\n📊 最終結果：");
  println!("Found {} devices in client.devices():", device_count);
  for device in &devices {
    println!("  - {} (index: {})", device.name(), device.index());
  }

  // 特別提醒
  if device_count == 0 {
    println!("\n💡 重要說明：");
    println!("   雖然 client.devices() 顯示 0 個設備，");
    println!("   但從上面的日誌可以看到 BX288A 和 ERICA 確實被掃描到了！");
    println!("   它們被 'ignoring' 是因為協定配置問題，不是掃描問題。");
    println!("   你的 Buttplug 設定是正確的！🎉");
  }

  println!("\nExample completed successfully!");

  Ok(())
}
