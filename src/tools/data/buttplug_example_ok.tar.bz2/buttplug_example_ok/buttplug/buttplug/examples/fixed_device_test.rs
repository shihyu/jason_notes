use buttplug::{
    client::ButtplugClientEvent,
    core::connector::ButtplugInProcessClientConnectorBuilder,
    core::message::Endpoint,
    server::{
        device::{
            configuration::{DeviceConfigurationManagerBuilder, ProtocolCommunicationSpecifier, BluetoothLESpecifier},
            ServerDeviceManagerBuilder,
            hardware::communication::btleplug::BtlePlugCommunicationManagerBuilder,
        },
        ButtplugServerBuilder,
    },
    client::ButtplugClient,
};
use futures_util::StreamExt;
use std::sync::Arc;
use std::collections::{HashMap, HashSet};
use tracing_subscriber;

#[tokio::main(flavor = "current_thread")]
async fn main() -> anyhow::Result<()> {
    // 啟用日誌
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .init();
    
    println!("🔧 使用修正配置測試設備匹配...");
    
    // 創建藍牙 LE 規範，只根據設備名稱匹配，忽略製造商資料
    let mut names = HashSet::new();
    names.insert("BX288A".to_owned());
    names.insert("ERICA".to_owned());
    
    let mut advertised_services = HashSet::new();
    advertised_services.insert("0000ffe0-0000-1000-8000-00805f9b34fb".parse().unwrap());
    
    let mut services = HashMap::new();
    let mut service_endpoints = HashMap::new();
    service_endpoints.insert(Endpoint::Tx, "0000ffe1-0000-1000-8000-00805f9b34fb".parse().unwrap());
    service_endpoints.insert(Endpoint::Rx, "0000ffe2-0000-1000-8000-00805f9b34fb".parse().unwrap());
    services.insert("0000ffe0-0000-1000-8000-00805f9b34fb".parse().unwrap(), service_endpoints);
    
    let btle_spec = ProtocolCommunicationSpecifier::BluetoothLE(BluetoothLESpecifier::new(
        names,
        vec![], // 空的製造商資料
        advertised_services,
        services,
    ));
    
    // 手動建立伺服器與設備配置
    let dcm = DeviceConfigurationManagerBuilder::default()
        .allow_raw_messages(false)
        .user_communication_specifier("svakom-v4", &[btle_spec])
        .finish()?;
    
    let mut device_manager_builder = ServerDeviceManagerBuilder::new(dcm);
    device_manager_builder.comm_manager(BtlePlugCommunicationManagerBuilder::default());
    let device_manager = device_manager_builder.finish()?;
    
    let server = ButtplugServerBuilder::new(device_manager).finish()?;
    
    let connector = ButtplugInProcessClientConnectorBuilder::default()
        .server(server)
        .finish();
    
    let client = ButtplugClient::new("Fixed Device Test Client");
    client.connect(connector).await?;
    
    println!("✅ 客戶端連接成功！");
    println!("等待適配器初始化...");
    tokio::time::sleep(tokio::time::Duration::from_secs(3)).await;
    
    // 設定事件監聽器
    let mut event_stream = client.event_stream();
    let event_client = Arc::new(client);
    
    tokio::spawn(async move {
        while let Some(event) = event_stream.next().await {
            match event {
                ButtplugClientEvent::DeviceAdded(device) => {
                    println!("🎉 設備成功加入: {}", device.name());
                    println!("   Index: {}", device.index());
                }
                ButtplugClientEvent::DeviceRemoved(device) => {
                    println!("❌ 設備移除: {}", device.name());
                }
                ButtplugClientEvent::ScanningFinished => {
                    println!("🔍 掃描完成");
                }
                ButtplugClientEvent::ServerDisconnect => {
                    println!("📡 伺服器斷線");
                    break;
                }
                _ => {}
            }
        }
    });
    
    // 開始掃描
    println!("🔍 開始設備掃描...");
    if let Err(e) = event_client.start_scanning().await {
        println!("掃描失敗: {}", e);
        return Ok(());
    }
    
    // 掃描 15 秒
    println!("⏳ 掃描 15 秒，看看是否能成功匹配設備...");
    for i in 1..=15 {
        tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
        let devices = event_client.devices();
        if !devices.is_empty() {
            println!("🎉 第 {} 秒: 找到 {} 個可控制的設備!", i, devices.len());
            for device in &devices {
                println!("   📱 {}", device.name());
            }
            break;
        } else if i % 5 == 0 {
            println!("⏳ 第 {} 秒: 仍在搜尋中...", i);
        }
    }
    
    // 停止掃描
    if let Err(e) = event_client.stop_scanning().await {
        println!("停止掃描失敗: {}", e);
    }
    
    // 最終結果
    let devices = event_client.devices();
    println!("\n📊 最終結果:");
    println!("找到 {} 個可控制的設備:", devices.len());
    
    if devices.is_empty() {
        println!("\n❌ 沒有找到可控制的設備");
        println!("💡 這可能意味著:");
        println!("   1. 用戶配置檔案沒有正確載入");
        println!("   2. 設備配置仍然有問題");
        println!("   3. 需要更深層的修改");
    } else {
        println!("\n🎉 成功修正！以下設備現在可以控制:");
        for device in &devices {
            println!("  📱 {} (index: {})", device.name(), device.index());
        }
    }
    
    println!("\n✅ 測試完成");
    Ok(())
}