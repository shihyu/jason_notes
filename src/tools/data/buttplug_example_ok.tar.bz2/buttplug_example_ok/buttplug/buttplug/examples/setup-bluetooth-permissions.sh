#!/bin/bash

# 設定 Buttplug 程式的藍牙權限腳本

echo "正在設定 Buttplug 程式的藍牙權限..."

# 方法 1: 使用 setcap 為編譯後的執行檔設定權限
echo "正在編譯程式..."
cargo build --example in_process_client_example --features btleplug-manager

if [ -f "../target/debug/examples/in_process_client_example" ]; then
    echo "為執行檔設定 CAP_NET_RAW 權限..."
    sudo setcap cap_net_raw+ep ../target/debug/examples/in_process_client_example
    echo "權限設定完成！現在可以不用 sudo 執行程式。"
    echo ""
    echo "執行指令："
    echo "cargo run --example in_process_client_example --features btleplug-manager"
    echo ""
    echo "或直接執行："
    echo "../target/debug/examples/in_process_client_example"
else
    echo "編譯失敗，請檢查程式碼。"
fi

echo ""
echo "如果你想要永久設定權限，請執行以下步驟："
echo "1. 創建 udev 規則："
echo "   sudo tee /etc/udev/rules.d/99-bluetooth-hci.rules <<EOF"
echo "   KERNEL==\"hci[0-9]*\", GROUP=\"bluetooth\", MODE=\"0660\""
echo "   SUBSYSTEM==\"bluetooth\", GROUP=\"bluetooth\", MODE=\"0664\""
echo "   EOF"
echo ""
echo "2. 重載 udev 規則："
echo "   sudo udevadm control --reload-rules"
echo "   sudo udevadm trigger"
echo ""
echo "3. 確認你在 bluetooth 群組中："
echo "   groups \$USER"
echo ""
echo "如果不在 bluetooth 群組，請執行："
echo "   sudo usermod -a -G bluetooth \$USER"
echo "   然後重新登入系統"