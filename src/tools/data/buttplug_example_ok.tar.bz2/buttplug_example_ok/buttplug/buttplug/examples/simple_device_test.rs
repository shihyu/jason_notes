use buttplug::{
    client::ButtplugClientEvent,
    util::in_process_client,
};
use futures_util::StreamExt;
use std::sync::Arc;
use tracing_subscriber;

#[tokio::main(flavor = "current_thread")]
async fn main() -> anyhow::Result<()> {
    // 啟用更詳細的日誌
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::TRACE)
        .init();
    
    println!("🔍 測試設備匹配問題...");
    
    // 建立客戶端，但這次啟用用戶設備配置載入
    let client = in_process_client("Device Test Client", true).await;
    
    println!("Client created successfully!");
    println!("正在等待適配器初始化...");
    tokio::time::sleep(tokio::time::Duration::from_secs(3)).await;
    
    // 設定事件監聽器
    let mut event_stream = client.event_stream();
    let event_client = Arc::new(client);
    
    // 背景任務處理事件
    tokio::spawn(async move {
        while let Some(event) = event_stream.next().await {
            match event {
                ButtplugClientEvent::DeviceAdded(device) => {
                    println!("🎉 設備成功新增: {}", device.name());
                    println!("   Index: {}", device.index());
                }
                ButtplugClientEvent::DeviceRemoved(device) => {
                    println!("❌ 設備移除: {}", device.name());
                }
                ButtplugClientEvent::ScanningFinished => {
                    println!("🔍 掃描完成");
                }
                ButtplugClientEvent::ServerDisconnect => {
                    println!("📡 伺服器斷線");
                    break;
                }
                _ => {}
            }
        }
    });
    
    // 開始掃描
    println!("🔍 開始設備掃描...");
    if let Err(e) = event_client.start_scanning().await {
        println!("掃描失敗: {}", e);
        return Ok(());
    }
    
    // 掃描 15 秒
    println!("⏳ 掃描 15 秒...");
    tokio::time::sleep(tokio::time::Duration::from_secs(15)).await;
    
    // 停止掃描
    if let Err(e) = event_client.stop_scanning().await {
        println!("停止掃描失敗: {}", e);
    }
    
    // 檢查結果
    let devices = event_client.devices();
    println!("\n📊 掃描結果:");
    println!("找到 {} 個可控制的設備:", devices.len());
    
    if devices.is_empty() {
        println!("\n📝 分析:");
        println!("   ✅ 藍牙掃描正常 - 能找到 BX288A 和 ERICA");
        println!("   ❌ 協定匹配失敗 - 製造商資料不匹配");
        println!("   💡 需要更新設備配置檔案");
        
        println!("\n🔧 可能的解決方案:");
        println!("   1. 聯繫 Buttplug 社群更新設備支援");
        println!("   2. 修改設備配置檔案以匹配你的設備");
        println!("   3. 等待官方支援更新");
    } else {
        for device in &devices {
            println!("  📱 {} (index: {})", device.name(), device.index());
        }
    }
    
    println!("\n✅ 測試完成");
    Ok(())
}