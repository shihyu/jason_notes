# Buttplug 藍牙設備掃描問題解決指南

## 📋 問題描述

用戶嘗試使用 Buttplug Rust 庫掃描藍牙設備（BX288A 和 ERICA），但遇到以下問題：
1. `BtlePlugCommunicationManager: false` - 藍牙通訊管理器未啟用
2. 無法找到已知的藍牙設備
3. 需要 sudo 權限才能執行

## 🔍 問題分析過程

### 1. 初始診斷

**檢查系統藍牙狀態：**
```bash
bluetoothctl show
bluetoothctl devices
```

**發現的設備：**
- `BX288A` (MAC: C0:23:11:16:0B:A5)
- `ERICA` (MAC: 68:96:14:10:35:57)

**結論：** 系統藍牙正常，設備已配對

### 2. 權限問題診斷

**用戶群組檢查：**
```bash
groups shihyu
# 輸出：shihyu : shihyu adm cdrom sudo dip plugdev users bluetooth lpadmin docker
```

**結論：** 用戶已在 `bluetooth` 群組中

### 3. Buttplug 日誌分析

**關鍵發現：**
```log
INFO buttplug::server::device::server_device_manager: BtlePlugCommunicationManager: false
```

**根本原因：** 
- `BtlePlugCommunicationManager` 的 `can_scan()` 方法回傳 `false`
- 這是因為 `adapter_connected` 狀態為 `false`
- 時序問題：適配器任務背景初始化，但伺服器建立時立即檢查狀態

## 🛠️ 解決方案

### 方案1：程式碼修改（解決時序問題）

**問題：** 適配器初始化有延遲

**解決：** 在客戶端初始化後等待適配器準備
```rust
// 等待適配器初始化
println!("Waiting for adapters to initialize...");
tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
```

### 方案2：權限設定（解決 sudo 需求）

#### 2.1 建立 udev 規則
```bash
# 建立規則檔案
sudo tee /etc/udev/rules.d/99-bluetooth-hci.rules <<EOF
KERNEL=="hci[0-9]*", GROUP="bluetooth", MODE="0660"
SUBSYSTEM=="bluetooth", GROUP="bluetooth", MODE="0664"
EOF

# 重載規則
sudo udevadm control --reload-rules
sudo udevadm trigger
```

#### 2.2 設定執行檔權限
```bash
# 編譯程式
cargo build --example in_process_client_example --features btleplug-manager

# 設定 CAP_NET_RAW 權限
sudo setcap cap_net_raw+ep ../target/debug/examples/in_process_client_example

# 驗證權限
getcap ../target/debug/examples/in_process_client_example
# 輸出：cap_net_raw=ep
```

## ✅ 最終解決方案

### 完整的程式碼範例

```rust
use buttplug::{
    client::ButtplugClientEvent,
    util::in_process_client,
};
use futures_util::StreamExt;
use std::sync::Arc;
use tracing_subscriber;

#[tokio::main(flavor = "current_thread")]
async fn main() -> anyhow::Result<()> {
    // 啟用詳細日誌
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::DEBUG)
        .init();
    
    println!("Starting Buttplug in-process client example...");
    
    // 建立 in-process 客戶端
    let client = in_process_client("Example Client", false).await;
    
    println!("Client created successfully!");
    println!("Client connected: {}", client.connected());
    
    // 等待適配器初始化
    println!("Waiting for adapters to initialize...");
    tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
    
    // 設定事件監聽器
    let mut event_stream = client.event_stream();
    let event_client = Arc::new(client);
    
    tokio::spawn(async move {
        while let Some(event) = event_stream.next().await {
            match event {
                ButtplugClientEvent::DeviceAdded(device) => {
                    println!("Device added: {}", device.name());
                }
                ButtplugClientEvent::DeviceRemoved(device) => {
                    println!("Device removed: {}", device.name());
                }
                ButtplugClientEvent::ScanningFinished => {
                    println!("Scanning finished");
                }
                ButtplugClientEvent::ServerDisconnect => {
                    println!("Server disconnected");
                    break;
                }
                _ => {
                    println!("Other event: {:?}", event);
                }
            }
        }
    });
    
    // 開始設備掃描
    println!("Starting device scan...");
    if let Err(e) = event_client.start_scanning().await {
        println!("Failed to start scanning: {}", e);
    }
    
    // 等待掃描完成
    for i in 1..=10 {
        tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
        let devices = event_client.devices();
        println!("Scan progress {}/10 - Found {} devices so far", i, devices.len());
        for device in &devices {
            println!("  - {} (index: {})", device.name(), device.index());
        }
    }
    
    // 停止掃描
    println!("Stopping device scan...");
    if let Err(e) = event_client.stop_scanning().await {
        println!("Failed to stop scanning: {}", e);
    }
    
    // 列出最終找到的設備
    let devices = event_client.devices();
    println!("Found {} devices:", devices.len());
    for device in devices {
        println!("  - {} (index: {})", device.name(), device.index());
    }
    
    println!("Example completed successfully!");
    
    Ok(())
}
```

### 自動權限設定腳本

```bash
#!/bin/bash
# setup-bluetooth-permissions.sh

echo "設定 Buttplug 程式的藍牙權限..."

# 編譯程式
cargo build --example in_process_client_example --features btleplug-manager

if [ -f "../target/debug/examples/in_process_client_example" ]; then
    echo "為執行檔設定 CAP_NET_RAW 權限..."
    sudo setcap cap_net_raw+ep ../target/debug/examples/in_process_client_example
    echo "權限設定完成！"
    echo ""
    echo "現在可以不用 sudo 執行："
    echo "cargo run --example in_process_client_example --features btleplug-manager"
else
    echo "編譯失敗，請檢查程式碼。"
fi
```

## 🎯 結果驗證

### 成功指標
1. ✅ `BtlePlugCommunicationManager: false` → 不再是問題（時序修正）
2. ✅ `Bluetooth LE adapter found.` → 適配器正常運作
3. ✅ 找到 BX288A 和 ERICA 設備
4. ✅ 無需 sudo 執行

### 執行輸出範例
```log
Starting Buttplug in-process client example...
INFO buttplug::server::device::hardware::communication::btleplug::btleplug_adapter_task: Bluetooth LE adapter found.
Client created successfully!
Client connected: true
Waiting for adapters to initialize...
DEBUG btleplug enumeration{address=...}: Found new bluetooth device advertisement: BX288A
INFO Device BX288A (...) found.
DEBUG btleplug enumeration{address=...}: Found new bluetooth device advertisement: ERICA
INFO Device ERICA (...) found.
Starting device scan...
Scan progress 1/10 - Found 0 devices so far
...
Example completed successfully!
```

## 📝 重要注意事項

### 1. 重新編譯後的權限設定
每次重新編譯後，需要重新設定權限：
```bash
sudo setcap cap_net_raw+ep ../target/debug/examples/in_process_client_example
```

### 2. 設備協定配置
雖然找到了 BX288A 和 ERICA，但出現：
```log
No viable protocols for hardware BluetoothLE(...), ignoring.
```

這表示需要在 Buttplug 設備配置檔案中添加這些設備的協定定義。

### 3. 系統要求
- Linux 系統
- 用戶必須在 `bluetooth` 群組中
- 需要管理員權限設定 udev 規則和執行檔權限

## 🔧 疑難排解

### 如果仍然需要 sudo
1. 檢查 udev 規則是否正確載入：`sudo udevadm control --reload-rules`
2. 檢查執行檔權限：`getcap your_executable`
3. 確認用戶在 bluetooth 群組：`groups $USER`

### 如果找不到設備
1. 確認設備已配對：`bluetoothctl devices`
2. 檢查設備是否在廣播模式
3. 增加掃描等待時間

### 如果權限設定失效
重新編譯後記得重新設定 `setcap` 權限，或考慮使用更持久的解決方案如 sudo 包裝腳本。

---

## 📚 相關資源

- [Buttplug 官方文檔](https://docs.buttplug.io/)
- [btleplug Rust 庫](https://github.com/deviceplug/btleplug)
- [Linux 藍牙權限設定](https://wiki.archlinux.org/title/Bluetooth)
- [udev 規則說明](https://www.freedesktop.org/software/systemd/man/udev.html)