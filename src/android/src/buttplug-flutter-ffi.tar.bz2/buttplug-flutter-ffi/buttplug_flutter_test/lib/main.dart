import 'package:flutter/material.dart';
import 'buttplug_wrapper.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Buttplug Flutter Test',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Buttplug FFI Test'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final ButtplugWrapper _buttplug = ButtplugWrapper();
  
  String _status = 'Not initialized';
  String _version = 'Unknown';
  bool _isLoading = false;
  Color _statusColor = Colors.red;

  @override
  void initState() {
    super.initState();
    _initializeLibrary();
  }

  Future<void> _initializeLibrary() async {
    setState(() {
      _isLoading = true;
      _status = 'Initializing...';
      _statusColor = Colors.orange;
    });

    try {
      final success = await _buttplug.initialize();
      
      setState(() {
        _isLoading = false;
        if (success) {
          _status = 'Library loaded successfully!';
          _statusColor = Colors.green;
          _version = _buttplug.getVersion();
        } else {
          _status = 'Failed to load library';
          _statusColor = Colors.red;
        }
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _status = 'Error: $e';
        _statusColor = Colors.red;
      });
    }
  }

  Future<void> _testConnection() async {
    if (!_buttplug.isInitialized) {
      _showSnackBar('Library not initialized');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final result = await _buttplug.testConnection();
      _showSnackBar(result ? 'Connection test passed!' : 'Connection test failed');
    } catch (e) {
      _showSnackBar('Test error: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    _buttplug.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Icon(
                Icons.smart_toy,
                size: 64,
                color: Colors.deepPurple,
              ),
              const SizedBox(height: 32),
              
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Text(
                        'Library Status',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _buttplug.isInitialized 
                                ? Icons.check_circle 
                                : Icons.error,
                            color: _statusColor,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _status,
                              style: TextStyle(
                                color: _statusColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (_isLoading) ...[
                        const SizedBox(height: 16),
                        const CircularProgressIndicator(),
                      ],
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Text(
                        'Library Information',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 16),
                      Text('Version: $_version'),
                      Text('Platform: Android'),
                      Text('FFI: ${_buttplug.isInitialized ? "Ready" : "Not Ready"}'),
                    ],
                  ),
                ),
              ),
              
              const SizedBox(height: 32),
              
              ElevatedButton.icon(
                onPressed: _isLoading ? null : _testConnection,
                icon: const Icon(Icons.play_arrow),
                label: const Text('Test Connection'),
              ),
              
              const SizedBox(height: 16),
              
              ElevatedButton.icon(
                onPressed: _isLoading ? null : _initializeLibrary,
                icon: const Icon(Icons.refresh),
                label: const Text('Reinitialize'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}