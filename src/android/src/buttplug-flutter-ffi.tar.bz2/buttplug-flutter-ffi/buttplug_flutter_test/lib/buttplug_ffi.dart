import 'dart:ffi';
import 'dart:io';
import 'package:ffi/ffi.dart';

class ButtplugFFI {
  static const String _libName = 'buttplug';
  late final DynamicLibrary _dylib;
  
  // 函數指針定義
  late final int Function() _buttplugTest;
  late final Pointer<Char> Function() _buttplugVersion;
  late final void Function(Pointer<Char>) _buttplugFreeString;
  
  ButtplugFFI() {
    try {
      if (Platform.isAndroid) {
        _dylib = DynamicLibrary.open('lib$_libName.so');
      } else if (Platform.isLinux) {
        _dylib = DynamicLibrary.open('lib$_libName.so');
      } else {
        throw UnsupportedError('Platform ${Platform.operatingSystem} is not supported');
      }
      
      // 綁定函數
      _buttplugTest = _dylib.lookupFunction<Int32 Function(), int Function()>('buttplug_test');
      _buttplugVersion = _dylib.lookupFunction<Pointer<Char> Function(), Pointer<Char> Function()>('buttplug_version');
      _buttplugFreeString = _dylib.lookupFunction<Void Function(Pointer<Char>), void Function(Pointer<Char>)>('buttplug_free_string');
      
      print('Successfully loaded Buttplug library');
    } catch (e) {
      print('Failed to load Buttplug library: $e');
      rethrow;
    }
  }

  // 測試函式庫是否正確載入
  bool isLibraryLoaded() {
    try {
      // 調用 Rust 導出的測試函數
      final result = _buttplugTest();
      return result == 1;
    } catch (e) {
      print('Error checking library: $e');
      return false;
    }
  }

  // 獲取庫版本信息
  String? getLibraryInfo() {
    try {
      final versionPtr = _buttplugVersion();
      if (versionPtr != nullptr) {
        final version = versionPtr.cast<Utf8>().toDartString();
        _buttplugFreeString(versionPtr);
        return "Buttplug library v$version loaded successfully";
      }
      return null;
    } catch (e) {
      print('Error getting library info: $e');
      return null;
    }
  }

  // 關閉函式庫
  void close() {
    try {
      _dylib.close();
      print('Buttplug library closed');
    } catch (e) {
      print('Error closing library: $e');
    }
  }
}
