import 'buttplug_ffi.dart';

/// Dart wrapper for Buttplug library
class ButtplugWrapper {
  late final ButtplugFFI _ffi;
  bool _isInitialized = false;

  /// 初始化 Buttplug 函式庫
  Future<bool> initialize() async {
    try {
      _ffi = ButtplugFFI();
      _isInitialized = _ffi.isLibraryLoaded();
      
      if (_isInitialized) {
        print('Buttplug wrapper initialized successfully');
      } else {
        print('Failed to initialize Buttplug wrapper');
      }
      
      return _isInitialized;
    } catch (e) {
      print('Error initializing Buttplug wrapper: $e');
      return false;
    }
  }

  /// 檢查是否已初始化
  bool get isInitialized => _isInitialized;

  /// 獲取函式庫版本資訊
  String getVersion() {
    if (!_isInitialized) {
      throw StateError('Buttplug wrapper not initialized');
    }
    
    final info = _ffi.getLibraryInfo();
    return info ?? 'Unknown version';
  }

  /// 測試函式庫連接
  Future<bool> testConnection() async {
    if (!_isInitialized) {
      return false;
    }
    
    try {
      // 這裡可以添加實際的測試邏輯
      // 目前只是驗證函式庫載入成功
      await Future.delayed(const Duration(milliseconds: 100));
      return true;
    } catch (e) {
      print('Connection test failed: $e');
      return false;
    }
  }

  /// 釋放資源
  void dispose() {
    if (_isInitialized) {
      _ffi.close();
      _isInitialized = false;
    }
  }
}