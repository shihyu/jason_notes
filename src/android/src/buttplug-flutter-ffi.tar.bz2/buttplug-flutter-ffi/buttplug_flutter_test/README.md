# Buttplug Flutter Test

Flutter 應用程式，用於測試 Buttplug Rust 函式庫的 FFI 整合。

## 專案結構

```
buttplug_flutter_test/
├── lib/
│   ├── main.dart           # 主應用程式 UI
│   ├── buttplug_ffi.dart   # FFI 綁定
│   └── buttplug_wrapper.dart # Dart 包裝器
├── android/app/src/main/jniLibs/
│   ├── arm64-v8a/libbuttplug.so    # ARM64 函式庫
│   ├── armeabi-v7a/libbuttplug.so  # ARM 32-bit 函式庫
│   ├── x86_64/libbuttplug.so       # x86_64 函式庫
│   └── x86/libbuttplug.so          # x86 32-bit 函式庫
└── build/app/outputs/flutter-apk/app-debug.apk
```

## 功能

- ✅ 載入 Buttplug 原生函式庫
- ✅ 驗證函式庫初始化
- ✅ 基本連接測試
- ✅ 友善的 UI 介面顯示狀態

## 測試內容

1. **函式庫載入**: 驗證 `libbuttplug.so` 能正確載入
2. **初始化檢查**: 確認 FFI 綁定工作正常
3. **版本資訊**: 顯示函式庫版本 (9.0.8)
4. **連接測試**: 基本功能測試

## 使用方法

### 建置
```bash
flutter pub get
flutter build apk --debug
```

### 安裝到 Android 裝置
```bash
flutter install
# 或
adb install build/app/outputs/flutter-apk/app-debug.apk
```

### 執行
```bash
flutter run
```

## 注意事項

- 需要 Android API 21+ (Android 5.0)
- 支援所有主要 Android 架構 (ARM64, ARM32, x86_64, x86)
- 目前為基本驗證版本，後續可擴展實際 Buttplug 功能

## 預期結果

當應用程式成功運行時，你應該看到：
- "Library loaded successfully!" 綠色狀態
- 版本顯示為 "9.0.8"
- FFI 狀態顯示為 "Ready"
- "Test Connection" 按鈕可以執行並顯示成功訊息

這確認了 Flutter 可以成功載入和調用 Buttplug Rust 函式庫。