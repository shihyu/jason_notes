package com.example.buttplug_flutter_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
