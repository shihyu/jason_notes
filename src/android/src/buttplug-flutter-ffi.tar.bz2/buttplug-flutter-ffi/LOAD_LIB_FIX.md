# Buttplug Android Load Library 修正報告

## 問題分析

### 原始問題
- Flutter 應用載入 `libbuttplug.so` 失敗
- FFI (Foreign Function Interface) 檢查無法找到預期的符號
- 導致 library status 顯示失敗

### 根本原因
1. **缺少 FFI 導出函數**: Rust 庫編譯為 `cdylib` 但沒有導出 C 兼容的函數
2. **符號檢查邏輯錯誤**: Flutter 代碼嘗試查找不存在的 Rust 內部符號
3. **類型匹配問題**: FFI 函數指針類型定義不正確

## 修正內容

### 1. 添加 Rust FFI 導出函數

**檔案**: `buttplug/buttplug/src/lib.rs`
```rust
// FFI 導出函數用於 Flutter
#[no_mangle]
pub extern "C" fn buttplug_version() -> *const std::os::raw::c_char {
    std::ffi::CString::new("9.0.8").unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn buttplug_test() -> std::os::raw::c_int {
    1
}

#[no_mangle]
pub extern "C" fn buttplug_free_string(s: *mut std::os::raw::c_char) {
    unsafe {
        if !s.is_null() {
            let _ = std::ffi::CString::from_raw(s);
        }
    }
}
```

### 2. 修正 Flutter FFI 綁定

**檔案**: `buttplug_flutter_test/lib/buttplug_ffi.dart`

**修正前**:
```dart
bool isLibraryLoaded() {
  // 嘗試查找不存在的符號
  final symbols = _dylib.providesSymbol('rust_eh_personality');
  return symbols;
}
```

**修正後**:
```dart
// 函數指針定義
late final int Function() _buttplugTest;
late final Pointer<Char> Function() _buttplugVersion;
late final void Function(Pointer<Char>) _buttplugFreeString;

// 在構造函數中綁定
_buttplugTest = _dylib.lookupFunction<Int32 Function(), int Function()>('buttplug_test');
_buttplugVersion = _dylib.lookupFunction<Pointer<Char> Function(), Pointer<Char> Function()>('buttplug_version');
_buttplugFreeString = _dylib.lookupFunction<Void Function(Pointer<Char>), void Function(Pointer<Char>)>('buttplug_free_string');

bool isLibraryLoaded() {
  try {
    final result = _buttplugTest();
    return result == 1;
  } catch (e) {
    return false;
  }
}
```

### 3. 更新版本信息獲取

**檔案**: `buttplug_flutter_test/lib/buttplug_wrapper.dart`
```dart
String getVersion() {
  if (!_isInitialized) {
    throw StateError('Buttplug wrapper not initialized');
  }
  
  final info = _ffi.getLibraryInfo();
  return info ?? 'Unknown version';
}
```

## 驗證步驟

### 1. 確認符號導出
```bash
nm -D libbuttplug.so | grep buttplug
# 輸出:
# 0000000000030268 T buttplug_free_string
# 0000000000030260 T buttplug_test  
# 00000000000301d8 T buttplug_version
```

### 2. 運行測試腳本
```bash
./test_apk.sh
```

### 3. 預期結果
- ✅ Library Status: 顯示綠色勾號，狀態為 "Library loaded successfully!"
- ✅ Version: 顯示 "Buttplug library v9.0.8 loaded successfully" 
- ✅ FFI: 顯示 "Ready"
- ✅ Test Connection: 按鈕功能正常
- ✅ Reinitialize: 按鈕功能正常

## 技術要點

### 1. Rust FFI 最佳實踐
- 使用 `#[no_mangle]` 防止符號名稱修飾
- 使用 `extern "C"` 確保 C ABI 兼容性
- 正確管理字符串記憶體 (分配與釋放)
- 使用 `std::os::raw::c_*` 類型確保平台兼容

### 2. Flutter FFI 最佳實踐  
- 使用正確的函數指針類型定義
- 處理 C 字符串與 Dart 字符串轉換
- 適當的錯誤處理和資源清理
- 使用 `Pointer<Char>.cast<Utf8>()` 進行類型轉換

### 3. 構建流程
1. 修改 Rust 源碼添加 FFI 函數
2. 重新編譯所有目標架構的庫
3. 複製新庫到 Flutter 專案
4. 更新 Flutter FFI 綁定代碼
5. 重新構建 APK
6. 測試驗證

## 問題預防

### 1. 持續集成檢查
- 自動驗證導出符號存在
- FFI 綁定測試
- APK 安裝和運行測試

### 2. 開發最佳實踐
- 版本更新時同步更新 FFI 函數
- 定期檢查庫依賴和兼容性
- 使用統一的錯誤處理模式

### 3. 測試覆蓋
- 單元測試：FFI 函數調用
- 整合測試：庫載入和初始化  
- 端到端測試：APK 安裝運行

## 相關文件

- **Rust 源碼**: `buttplug/buttplug/src/lib.rs`
- **Flutter FFI**: `buttplug_flutter_test/lib/buttplug_ffi.dart`
- **Flutter Wrapper**: `buttplug_flutter_test/lib/buttplug_wrapper.dart`
- **測試腳本**: `test_apk.sh`
- **構建腳本**: `Makefile`
- **APK 輸出**: `buttplug_flutter_test/build/app/outputs/flutter-apk/app-debug.apk`

## 總結

通過添加適當的 FFI 導出函數和修正 Flutter 端的綁定代碼，成功解決了 library 載入失敗的問題。現在應用能夠：

1. 正確載入 Rust 庫
2. 驗證庫功能正常  
3. 獲取版本信息
4. 執行測試功能

修正已完成，可以進行反覆驗證測試。
